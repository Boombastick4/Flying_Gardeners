//Adding the sequential Gearbox recepie

craftingTable.addShaped("sequential_gearbox", <item:create_compact_transmission:four_speed_transmission>, [
    [<item:minecraft:air>, <item:create:gearshift>, <item:minecraft:air>],
    [<item:create:gearshift>,<item:create:precision_mechanism> , <item:create:gearshift>],
    [<item:minecraft:air>, <item:create:gearbox>, <item:minecraft:air>]
]);
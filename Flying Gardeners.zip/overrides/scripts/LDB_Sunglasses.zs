// Remove the old recipe
craftingTable.remove(<item:beachparty:sunglasses>);

// Add the new recipe
craftingTable.addShaped("sunglasses", <item:beachparty:sunglasses>, [
    [<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:air>],
    [<item:minecraft:stick>, <item:minecraft:air>, <item:minecraft:stick>],
    [<item:minecraft:black_stained_glass_pane>, <item:minecraft:stick>, <item:minecraft:black_stained_glass_pane>]

]);
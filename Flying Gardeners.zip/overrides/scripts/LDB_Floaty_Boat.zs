// Remove the old recipe
craftingTable.remove(<item:beachparty:floaty_boat>);

// Add the new recipe
craftingTable.addShaped("floaty_boat", <item:beachparty:floaty_boat>, [
    [<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:air>],
    [<item:beachparty:rubber_ring_blue>, <item:minecraft:air>, <item:minecraft:dried_kelp>],
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>]

]);
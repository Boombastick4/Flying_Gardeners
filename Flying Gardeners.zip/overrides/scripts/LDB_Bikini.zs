// Remove the old recipe
craftingTable.remove(<item:beachparty:bikini>);

// Add the new recipe
craftingTable.addShaped("bikini", <item:beachparty:bikini>, [
    [<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:air>],
    [<item:minecraft:dried_kelp>, <item:minecraft:string>, <item:minecraft:dried_kelp>],
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>]

]);
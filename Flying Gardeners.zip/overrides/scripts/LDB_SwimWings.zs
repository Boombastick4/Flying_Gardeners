// Remove the old recipe
craftingTable.remove(<item:beachparty:swim_wings>);

// Add the new recipe
craftingTable.addShaped("swim_wings", <item:beachparty:swim_wings>, [
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:air>],
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:air>],
    [<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:air>]

]);

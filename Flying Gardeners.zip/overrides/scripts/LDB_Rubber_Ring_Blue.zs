// Remove the old recipe
craftingTable.remove(<item:beachparty:rubber_ring_blue>);

// Add the new recipe
craftingTable.addShaped("rubber_ring_blue", <item:beachparty:rubber_ring_blue>, [
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>],
    [<item:minecraft:dried_kelp>, <item:minecraft:blue_dye>, <item:minecraft:dried_kelp>],
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>]

]);
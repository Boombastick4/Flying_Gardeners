// Remove the old recipe
craftingTable.remove(<item:beachparty:trunks>);

// Add the new recipe
craftingTable.addShaped("trunks", <item:beachparty:trunks>, [
    [<item:minecraft:string>, <item:minecraft:string>, <item:minecraft:string>],
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>],
    [<item:minecraft:dried_kelp>, <item:minecraft:air>, <item:minecraft:dried_kelp>]

]);
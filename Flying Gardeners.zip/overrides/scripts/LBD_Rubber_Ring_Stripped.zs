// Remove the old recipe
craftingTable.remove(<item:beachparty:rubber_ring_stripped>);

// Add the new recipe
craftingTable.addShaped("rubber_ring_striped", <item:beachparty:rubber_ring_stripped>, [
    [<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:air>],
    [<item:beachparty:rubber_ring_blue>, <item:beachparty:rubber_ring_pink>, <item:minecraft:air>],
    [<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:air>]

]);
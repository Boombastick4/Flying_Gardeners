// Remove the old recipe
craftingTable.remove(<item:beachparty:beach_ball>);

// Add the new recipe
craftingTable.addShaped("beach_ball", <item:beachparty:beach_ball>, [
    [<item:minecraft:air>, <item:minecraft:dried_kelp>, <item:minecraft:air>],
    [<item:minecraft:dried_kelp>, <item:minecraft:air>, <item:minecraft:dried_kelp>],
    [<item:minecraft:air>, <item:minecraft:dried_kelp>, <item:minecraft:air>]

]);
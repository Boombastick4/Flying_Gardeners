// Remove the old recipe
craftingTable.remove(<item:beachparty:rubber_ring_pink>);

// Add the new recipe
craftingTable.addShaped("rubber_ring_pink", <item:beachparty:rubber_ring_pink>, [
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>],
    [<item:minecraft:dried_kelp>, <item:minecraft:pink_dye>, <item:minecraft:dried_kelp>],
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>]

]);
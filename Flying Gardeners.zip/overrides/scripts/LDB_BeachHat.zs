// Remove the old recipe
craftingTable.remove(<item:beachparty:beach_hat>);

// Add the new recipe
craftingTable.addShaped("beach_hat", <item:beachparty:beach_hat>, [
    [<item:minecraft:air>, <item:minecraft:wheat>, <item:minecraft:air>],
    [<item:minecraft:air>, <item:minecraft:string>, <item:minecraft:air>],
    [<item:minecraft:wheat>, <item:minecraft:wheat>, <item:minecraft:wheat>]

]);
//This is other recepies that might cause issues/unwanted behaviour

//The item silo creates a duplication when turning into a physics object and back. it iwll be removed
craftingTable.remove(<item:create_connected:item_silo>);
// Remove the old recipe. Aparently it causes bugs on the server. 
craftingTable.remove(<item:addictives:cigarette_pack>);
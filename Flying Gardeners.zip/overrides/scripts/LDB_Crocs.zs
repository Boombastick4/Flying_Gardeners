// Remove the old recipe
craftingTable.remove(<item:beachparty:crocs>);

// Add the new recipe
craftingTable.addShaped("crocs", <item:beachparty:crocs>, [
    [<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:air>],
    [<item:minecraft:dried_kelp>, <item:minecraft:air>, <item:minecraft:air>],
    [<item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>, <item:minecraft:dried_kelp>]

]);
// Add the new recipe
craftingTable.addShaped("pool_noodle", <item:beachparty:pool_noodle>, [
    [<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:dried_kelp>],
    [<item:minecraft:air>, <item:minecraft:dried_kelp>, <item:minecraft:air>],
    [<item:minecraft:dried_kelp>, <item:minecraft:air>, <item:minecraft:air>]

]);
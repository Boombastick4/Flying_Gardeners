//This file removes any items/recepies/methods that cause the game to crash
//you can still obtain these items via creative mode or commands, but in regular survival, you wont obtain them
craftingTable.remove(<item:crittersandcompanions:grappling_hook>);